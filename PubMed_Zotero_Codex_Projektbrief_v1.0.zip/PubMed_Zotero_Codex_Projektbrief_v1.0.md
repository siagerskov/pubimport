# Projektbrief till Codex: Automatisk PubMed-bevakning till Zotero

**Version:** 1.0  
**Datum:** 2026-11-01  
**Status:** Kravspecifikation för implementation (ingen driftsättning genomförd)  
**Projekt:** `pubmed-zotero`

## 1. Uppdrag till Codex

Bygg ett kostnadsfritt, robust och dokumenterat system som automatiskt söker efter nya vetenskapliga publikationer i PubMed, importerar relevanta referenser till en särskild inkorg i användarens Zotero-bibliotek och låter användaren manuellt kvalitetsgranska och godkänna referenserna. Systemet ska vara möjligt att driva utan att användarens egen dator är påslagen.

**Viktigt:** Utvecklingen ska ske stegvis, med fullständig teknisk dokumentation **under arbetets gång**, inte retroaktivt. Ändringar av funktionalitet måste åtföljas av relevanta tester, uppdaterad dokumentation och ändringslogg. Kod, tester och dokumentation ska versionshanteras tillsammans.

Arbeta självständigt med rimliga tekniska standardval, men gör inte säkerhetskänsliga eller destruktiva externa åtgärder utan uttryckligt godkännande. Begär aldrig att användaren klistrar in en API-nyckel i chatten eller i källkod.

## 2. Önskat användarflöde

1. En schemalagd körning söker PubMed automatiskt en gång per dygn.
2. Sökningar definieras i versionshanterade konfigurationsfiler; initialt två bevakningsområden: **MSK-radiologi** och **AI inom radiologi**.
3. Nya träffar hämtas med bibliografiska metadata och förses med sök- och importproveniens.
4. Dubbletter identifieras innan import med i första hand PMID och sekundärt DOI, med dokumenterad hantering av saknade identifierare.
5. Nya referenser läggs i Zotero-samlingen `00 – Automatisk import` och dess ämnesundersamlingar. De märks `Ej granskad`.
6. Användaren granskar i Zotero och väljer att godkänna, avvakta eller exkludera artiklar, i första versionen genom dokumenterade manuella steg (samlingar och/eller taggar).
7. Godkända referenser hör hemma i `01 – Granskade och godkända`; ämnes- och projektsamlingar kan användas därutöver.
8. Systemet ska inte ändra godkännandestatus automatiskt eller radera användarens referenser.

### Principer för Zotero

- `00 – Automatisk import` är en **inkorg**, inte en evidensgranskad litteraturdatabas.
- Initiala undersamlingar: `MSK-radiologi`, `AI inom radiologi`.
- `01 – Granskade och godkända` för manuellt accepterade referenser.
- `02 – Projekt och litteraturöversikter` för framtida projektvisa samlingar.
- Använd entydiga status-taggar (föreslå till exempel `status/ej-granskad`, `status/godkand`, `status/avvakta`, `status/exkluderad`) och dokumentera hur man undviker motstridiga statusar.
- Zotero-referenser kan ligga i flera samlingar. Specificera om "godkännande" sker genom tillägg till en samling, borttagning från inkorg och/eller taggändring. Var noga med att dessa handlingar inte betyder att referensen måste dupliceras.
- Systemet ska respektera användarens manuella ändringar vid efterföljande körningar.

## 3. Omfattning och avgränsning

### Ingår i första leveransen (MVP)

- Python-baserad PubMed-integration via NCBI E-utilities eller annan officiell, dokumenterad PubMed-väg.
- Daglig schemaläggning med GitHub Actions.
- Zotero-integration via officiellt Zotero Web API.
- Konfigurerbara söksträngar för de två ämnena.
- Hämtning och normalisering av titel, författare, tidskrift, publikationsdatum, abstract när tillgängligt, PMID, DOI och relevanta länkar.
- Robust dubblettkontroll, återkörning utan oavsiktlig dubbelimport (idempotens) och stöd för överlapp mellan bevakningar.
- Skapande/identifiering av Zotero-samlingar.
- Säker lagring av API-uppgifter i GitHub Actions Secrets och endast minsta nödvändiga behörighet.
- Loggning, felhantering, möjlighet till manuell testkörning och dry-run.
- Dokumentation, automatiserade tester och en verifierad installationsprocedur.

### Ingår inte utan ett senare beslut

- Automatisk AI-baserad evidensgradering eller slutligt urval.
- Automatisk nedladdning och lagring av fulltext-PDF (upphovsrätt, tillgång och lagringsgränser behöver bedömas separat).
- Obevakad borttagning, sammanslagning eller överskrivning av befintliga Zotero-poster.
- Krav på att en LLM/Codex ska köra de dagliga sökningarna.
- Betald driftplattform eller kommersiell referenshanterare.

## 4. Föreslagen arkitektur

```text
GitHub Actions (schemalagd + manuell körning)
              |
              v
       Python-pipeline
          |       |
          v       v
   PubMed API   Konfiguration (YAML)
          |
          v
   Normalisering + validering
          |
          v
   Dubblettkontroll / idempotens
          |
          v
    Zotero Web API
          |
          v
  Inkorg: Ej granskade referenser
          |
          v
  Manuell granskning i Zotero
```

Lösningen ska i första hand vara **stateless**: läs vid behov befintliga Zotero-poster och importera endast nya, i stället för att förutsätta en permanent lokal databas. Om en persistensmekanism behövs ska den motiveras och dokumenteras. Planera för API-paginering, hastighetsbegränsning, timeout, retry med exponential backoff och partiella fel.

## 5. Sökstrategi och proveniens

- Skapa `config/searches.yaml` med en tydlig post per bevakning: ID, titel, aktiverad/inaktiverad, fullständig PubMed-query, eventuellt datumfönster, versionsnummer och beskrivning.
- Börja med välavgränsade, förklarade **förslag** för MSK-radiologi respektive AI inom radiologi. Lås inte söksträngarna som slutgiltiga utan att de kan granskas kliniskt.
- Undvik enbart tidskriftsfilter som riskerar att missa relevanta artiklar. Särskilj högspecificitetssökning från senare justerbara urvalskriterier.
- Använd ett överlappande datumfönster vid daglig körning för att fånga eftersläpande PubMed-indexering; kombinera med idempotens för att undvika dubbletter.
- Logga åtminstone: bevaknings-ID, söksträngsversion, söktidpunkt i UTC, identifierare, datum för upptäckt och importstatus. Välj ett Zotero-kompatibelt sätt att lagra proveniens utan att skriva över användarens egna anteckningar eller bibliografiska data.
- Flera sökningar kan hitta samma PMID. Skapa en Zotero-post med rätt ämnestillhörighet och spårbarhet till alla relevanta sökningar.
- Definitionen av "ny" ska specificeras, inklusive senare tillagda metadata och korrigerade PubMed-poster.

## 6. Säkerhet och sekretess

- API-nycklar och Zotero-identifierare sätts genom miljövariabler/secrets; inga hemligheter i repositoryt eller loggar.
- En Zotero API-nyckel med minsta möjliga åtkomst används; skrivbehörighet enbart där nödvändigt.
- Hemligheter får inte exponeras i pull requests, testutskrifter eller felmeddelanden.
- Versionslåsning eller kontrollerad versionshantering av beroenden; Dependabot eller likvärdig uppdateringsrutin kan föreslås.
- Använd minimala GitHub Actions-behörigheter och dokumentera risker vid exekvering från externa bidrag.
- Projektet hanterar publika vetenskapliga referenser, inte patientdata; inför inte patientuppgifter i sökningar, loggar eller Zotero via detta arbetsflöde.

## 7. Tester och acceptanskriterier

Skapa unit tests med mockade API-svar, integrationstester utan verklig Zotero-skrivning som standard samt ett separat, explicit godkänt end-to-end-test.

| Testfall | Godkänt när |
|---|---|
| Ny PMID | En korrekt referens importeras till rätt inkorg |
| Samma PMID vid omkörning | Ingen ytterligare Zotero-post skapas |
| Överlappande sökningar | En post, korrekt koppling till flera bevakningar |
| Samma DOI, annat/okänt PMID | Dubblettlogik följer dokumenterad prioritet |
| Metadata saknas | Kontrollerad fallback, inga felaktigt fabricerade värden |
| PubMed-/Zotero-timeout eller 429/5xx | Begränsade återförsök och tydlig fellogg |
| Partiellt batchfel | Säkert återupptag, inga dubbla importer |
| Manuell godkänd status | Status och samlingar respekteras vid omkörning |
| Dry-run | Ingen extern skrivning sker |
| Ogiltiga hemligheter | Säker felrapportering utan läckage |
| Ändrad söksträng | Ny sökversion kan följas i körlogg |

**MVP accepteras först när:** en dry-run fungerar, automatiserade tester passerar, ett litet piloturval har kontrollerats manuellt i Zotero, återkörning är verifierat idempotent och en installation kan följas från dokumentationen utan muntliga instruktioner.

## 8. Drift och övervakning

- Daglig schemalagd körning i GitHub Actions, med explicit tidszonshantering (kör gärna i UTC).
- Manuell trigger för test och felsökning.
- Sammanfattning per körning: antal PubMed-träffar, antal nya, antal redan kända, antal importerade, antal fel.
- Icke-noll exit-status vid väsentligt fel så att GitHub markerar misslyckad körning.
- Beskriv hur användaren ser körhistorik och aktiverar GitHub-notifieringar om fel.
- Dokumentera GitHubs begränsningar för schemaläggning, lagring och användningskvoter; utgå inte från garanterad körning exakt på minuten eller obegränsad gratiskapacitet.
- Beskriv backup/återställning av konfiguration och hur Zotero-data återfås, inklusive export som möjlig extra säkerhetsåtgärd.

## 9. Obligatorisk dokumentation – upprättas löpande

Följande filer ska finnas i repositoryt och hållas aktuella:

```text
pubmed-zotero/
├── README.md
├── AGENTS.md
├── CHANGELOG.md
├── pyproject.toml
├── .env.example                 # endast variabelnamn, aldrig nycklar
├── config/
│   └── searches.yaml
├── src/pubmed_zotero/
│   ├── pubmed.py
│   ├── zotero.py
│   ├── deduplication.py
│   ├── pipeline.py
│   └── models.py
├── tests/
├── docs/
│   ├── 01-systemoversikt.md
│   ├── 02-teknisk-specifikation.md
│   ├── 03-installation.md
│   ├── 04-sokstrategier.md
│   ├── 05-sakerhet.md
│   ├── 06-validering.md
│   ├── 07-drift-underhall.md
│   ├── 08-arkitekturbeslut.md
│   └── 09-anvandarmanual-zotero.md
└── .github/workflows/
    ├── tests.yml
    └── pubmed-sync.yml
```

Dokumentationens minimikrav:

1. **Systemöversikt:** mål, avgränsning, arkitekturskiss och dataflöde.
2. **Teknisk specifikation:** API-endpoints, autentisering, datamodeller, mappning mot Zotero, felhantering och dedupliceringsalgoritm.
3. **Installation:** steg-för-steg från tomt GitHub- och Zotero-konto till första verifierade körning, inklusive felsökning.
4. **Sökstrategier:** fullständiga söksträngar, MeSH/fritext, motiv, version, testträffar och begränsningar.
5. **Säkerhet:** hotbild, secrets, behörigheter, loggar och återkallning/rotation av nycklar.
6. **Validering:** testmatris, instruktioner, genomförda utfall och kända begränsningar.
7. **Drift/underhåll:** rutin för schema, manuell körning, fellarm, beroendeuppdatering, återställning och ändringar i API:er.
8. **Arkitekturbeslut (ADR):** varje större beslut med datum, alternativ, rationale och konsekvenser.
9. **Användarmanual:** konkret arbetsflöde i Zotero för godkänn/avvakta/exkludera samt sökning och filtrering.
10. **CHANGELOG:** användarbetydande ändringar per version.

Skapa även `AGENTS.md` med **obligatoriska projektregler**: ändra aldrig beteende utan motsvarande test, dokumentation och changelog; håll integrationerna mockbara; kör formattering/lint/test före leverans; lagra aldrig hemligheter; gör aldrig oombedda destruktiva ändringar i Zotero; redovisa antaganden och återstående risker.

## 10. Genomförandeplan för Codex

**Etapp 0 – Projektbootstrap**  
Skapa repositorystruktur, AGENTS.md, README, licensförslag, utvecklingsmiljö, CI och dokumentationsskelett. Lägg till checklista för användarens konton och API-nycklar. Dokumentera antaganden.

**Etapp 1 – PubMed-läsning**  
Implementera konfigurerbara sökningar och metadatahämtning, med fixtures och tester. Visa provutdata utan Zotero-skrivning. Dokumentera sökstrategi och API-kontrakt.

**Etapp 2 – Zotero-inkorg**  
Implementera autentisering, samlingshantering, mappning och dry-run. Dokumentera installation och åtkomstmodell.

**Etapp 3 – Idempotent synkning**  
Implementera deduplicering, överlapp mellan bevakningar, manuella statusar, retries och tydlig körsammanfattning. Utöka testmatrisen.

**Etapp 4 – Automatisk drift**  
Skapa GitHub Actions-workflow, secrets-instruktioner, notifieringsrutin och validering av körning utan lokal dator.

**Etapp 5 – Pilot och driftsättning**  
Genomför endast efter användarens uttryckliga godkännande av Zotero-skrivning. Begränsa testimporten, verifiera poster manuellt, testa omkörning och dokumentera resultat. Aktivera därefter ordinarie schema.

Vid slutet av **varje etapp**, lämna: sammanfattning av utfört arbete, ändrade filer, körda tester/resultat, uppdaterad dokumentation, risker/kända brister och föreslagen nästa etapp. Markera tydligt om något är implementerat men ännu inte verifierat i verklig drift.

## 11. Frågor som får behöva användarbeslut

- Zotero-konto och om biblioteket ska vara privat/personligt (standard) eller en separat Zotero-grupp.
- GitHub-konto och privat eller publikt repository (föreslå privat som utgångspunkt).
- Godkännande av initiala PubMed-söksträngar och önskad precision/recall.
- Inställning och säker hantering av Zotero API-nyckel samt eventuella PubMed/NCBI-uppgifter.
- Godkännande före första verkliga import och före aktivering av daglig körning.

Gör tekniskt arbete som inte kräver dessa beslut först; hårdkoda inte gissade konton, identifierare eller hemligheter.

## 12. Första instruktionen till Codex

> Läs hela denna projektbrief. Skapa först repositorystruktur, `AGENTS.md`, arkitekturdokumentation och en detaljerad implementationsplan. Genomför därefter etapp 0 och etapp 1 med testbar Python-kod och automatiserade tester. Håll teknisk dokumentation och ändringslogg synkroniserade med varje kodändring. Använd mockade integrationer tills användaren uttryckligen godkänt extern Zotero-skrivning. Redovisa vilka filer som skapats, vilka tester som körts, eventuella antaganden och vad som återstår innan faktisk driftsättning. Fortsätt sedan etappvis enligt planen.

---

**Definition av framgång:** Efter installation kan nya PubMed-referenser automatiskt hamna i en avgränsad Zotero-inkorg med spårbarhet och utan dubbletter. Användaren kan godkänna artiklar manuellt i Zotero. En annan utvecklare ska kunna förstå, verifiera, återinstallera och underhålla systemet utifrån repositoryts dokumentation.
